package com.minhtin.PhoneDB.controller;

import com.minhtin.PhoneDB.model.CategoryMaster;
import com.minhtin.PhoneDB.repository.CategoryMasterRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@CrossOrigin(origins = "http://localhost:8081")
@RestController
@RequestMapping("/api")
public class CategoryMasterController {
    @Autowired
    CategoryMasterRepository categoryMasterRepository;

    @GetMapping("/category_master")
    public ResponseEntity<List<CategoryMaster>> getAll(@RequestParam(required = false) String categoryCd) {
        try {
            List<CategoryMaster> categoryMasters = new ArrayList<>();

            if (categoryCd == null) {
                categoryMasterRepository.findAll().forEach(categoryMasters::add);
            } else {
                categoryMasterRepository.findByCategoryCdContaining(categoryCd).forEach(categoryMasters::add);
            }

            if (categoryMasters.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

            return new ResponseEntity<>(categoryMasters, HttpStatus.OK);
        } catch (Exception e) {
            e.printStackTrace();
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/category_master/{id}")
    public ResponseEntity<CategoryMaster> getById(@PathVariable("id") Integer id) {
        Optional<CategoryMaster> data = categoryMasterRepository.findById(id);

        if (data.isPresent()) {
            return new ResponseEntity<>(data.get(), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @PostMapping("/category_master")
    public ResponseEntity<CategoryMaster> create(@RequestBody CategoryMaster categoryMaster) {
        try {
            CategoryMaster _categoryMaster = categoryMasterRepository.save(new CategoryMaster(
                    categoryMaster.getCategoryCd(),
                    categoryMaster.getCategoryNm(),
                    categoryMaster.getCategoryContent(),
                    categoryMaster.getLinkCategoryCd(),
                    categoryMaster.getUpdateUserId(),
                    categoryMaster.getUpdateDate(),
                    categoryMaster.getVisibleFlg(),
                    categoryMaster.getDelUserId(),
                    categoryMaster.getDelDate(),
                    categoryMaster.getDelFlg(),
                    categoryMaster.getRevision()
            ));
            return new ResponseEntity<>(_categoryMaster, HttpStatus.CREATED);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PutMapping("/category_master/{id}")
    public ResponseEntity<CategoryMaster> update(@PathVariable("id") Integer id, @RequestBody CategoryMaster categoryMaster) {
        Optional<CategoryMaster> data = categoryMasterRepository.findById(id);

        if (data.isPresent()) {
            CategoryMaster _categoryMaster = data.get();
            _categoryMaster.setCategoryCd(categoryMaster.getCategoryCd());
            _categoryMaster.setCategoryNm(categoryMaster.getCategoryNm());
            _categoryMaster.setCategoryContent(categoryMaster.getCategoryContent());
            _categoryMaster.setLinkCategoryCd(categoryMaster.getLinkCategoryCd());
            _categoryMaster.setUpdateUserId(categoryMaster.getUpdateUserId());
            _categoryMaster.setUpdateDate(categoryMaster.getUpdateDate());
            _categoryMaster.setVisibleFlg(categoryMaster.getVisibleFlg());
            _categoryMaster.setDelUserId(categoryMaster.getDelUserId());
            _categoryMaster.setDelDate(categoryMaster.getDelDate());
            _categoryMaster.setDelFlg(categoryMaster.getDelFlg());
            _categoryMaster.setRevision(categoryMaster.getRevision());
            return new ResponseEntity<>(categoryMasterRepository.save(_categoryMaster), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/category_master/{id}")
    public ResponseEntity<HttpStatus> deleteById(@PathVariable("id") Integer id) {
        try {
            categoryMasterRepository.deleteById(id);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/category_master")
    public ResponseEntity<HttpStatus> deleteAll() {
        try {
            categoryMasterRepository.deleteAll();
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
