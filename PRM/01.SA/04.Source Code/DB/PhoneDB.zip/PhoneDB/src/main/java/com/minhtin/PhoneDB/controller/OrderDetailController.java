package com.minhtin.PhoneDB.controller;

import com.minhtin.PhoneDB.model.OrderDetail;
import com.minhtin.PhoneDB.repository.OrderDetailRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@CrossOrigin(origins = "http://localhost:8081")
@RestController
@RequestMapping("/api")
public class OrderDetailController {
    @Autowired
    OrderDetailRepository orderDetailRepository;

    @GetMapping("/order_detail")
    public ResponseEntity<List<OrderDetail>> getAll(@RequestParam(required = false) String orderCd) {
        try {
            List<OrderDetail> orderDetails = new ArrayList<>();

            if (orderCd == null) {
                orderDetailRepository.findAll().forEach(orderDetails::add);
            } else {
                orderDetailRepository.findByOrderCdContaining(orderCd).forEach(orderDetails::add);
            }

            if (orderDetails.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

            return new ResponseEntity<>(orderDetails, HttpStatus.OK);
        } catch (Exception e) {
            e.printStackTrace();
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/order_detail/{id}")
    public ResponseEntity<OrderDetail> getById(@PathVariable("id") Integer id) {
        Optional<OrderDetail> data = orderDetailRepository.findById(id);

        if (data.isPresent()) {
            return new ResponseEntity<>(data.get(), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @PostMapping("/order_detail")
    public ResponseEntity<OrderDetail> create(@RequestBody OrderDetail orderDetail) {
        try {
            OrderDetail _orderDetail = orderDetailRepository.save(new OrderDetail(
                    orderDetail.getOrderCd(),
                    orderDetail.getProductCd(),
                    orderDetail.getProductNm(),
                    orderDetail.getShipperCd(),
                    orderDetail.getShipperNm(),
                    orderDetail.getStoreCd(),
                    orderDetail.getStoreNm(),
                    orderDetail.getDateFrom(),
                    orderDetail.getDateTo(),
                    orderDetail.getPrice(),
                    orderDetail.getQuantity(),
                    orderDetail.getServiceCd(),
                    orderDetail.getServiceNm(),
                    orderDetail.getUpdateUserId(),
                    orderDetail.getUpdateDate(),
                    orderDetail.getVisibleFlg(),
                    orderDetail.getDelUserId(),
                    orderDetail.getDelDate(),
                    orderDetail.getDelFlg(),
                    orderDetail.getRevision()
            ));
            return new ResponseEntity<>(_orderDetail, HttpStatus.CREATED);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PutMapping("/order_detail/{id}")
    public ResponseEntity<OrderDetail> update(@PathVariable("id") Integer id, @RequestBody OrderDetail orderDetail) {
        Optional<OrderDetail> data = orderDetailRepository.findById(id);

        if (data.isPresent()) {
            OrderDetail _orderDetail = data.get();
            _orderDetail.setOrderCd(orderDetail.getOrderCd());
            _orderDetail.setProductCd(orderDetail.getProductCd());
            _orderDetail.setProductNm(orderDetail.getProductNm());
            _orderDetail.setShipperCd(orderDetail.getShipperCd());
            _orderDetail.setShipperNm(orderDetail.getShipperNm());
            _orderDetail.setOrderCd(orderDetail.getStoreCd());
            _orderDetail.setStoreNm(orderDetail.getStoreNm());
            _orderDetail.setDateFrom(orderDetail.getDateFrom());
            _orderDetail.setDateTo(orderDetail.getDateTo());
            _orderDetail.setPrice(orderDetail.getPrice());
            _orderDetail.setQuantity(orderDetail.getQuantity());
            _orderDetail.setServiceCd(orderDetail.getServiceCd());
            _orderDetail.setServiceNm(orderDetail.getServiceNm());
            _orderDetail.setUpdateUserId(orderDetail.getUpdateUserId());
            _orderDetail.setUpdateDate(orderDetail.getUpdateDate());
            _orderDetail.setVisibleFlg(orderDetail.getVisibleFlg());
            _orderDetail.setDelUserId(orderDetail.getDelUserId());
            _orderDetail.setDelDate(orderDetail.getDelDate());
            _orderDetail.setDelFlg(orderDetail.getDelFlg());
            _orderDetail.setRevision(orderDetail.getRevision());
            return new ResponseEntity<>(orderDetailRepository.save(_orderDetail), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/order_detail/{id}")
    public ResponseEntity<HttpStatus> deleteById(@PathVariable("id") Integer id) {
        try {
            orderDetailRepository.deleteById(id);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/order_detail")
    public ResponseEntity<HttpStatus> deleteAll() {
        try {
            orderDetailRepository.deleteAll();
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
