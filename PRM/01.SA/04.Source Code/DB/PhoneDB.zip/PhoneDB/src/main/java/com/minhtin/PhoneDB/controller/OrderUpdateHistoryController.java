package com.minhtin.PhoneDB.controller;

import com.minhtin.PhoneDB.model.OrderUpdateHistory;
import com.minhtin.PhoneDB.repository.OrderUpdateHistoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@CrossOrigin(origins = "http://localhost:8081")
@RestController
@RequestMapping("/api")
public class OrderUpdateHistoryController {
    @Autowired
    OrderUpdateHistoryRepository orderUpdateHistoryRepository;

    @GetMapping("/order_update_history")
    public ResponseEntity<List<OrderUpdateHistory>> getAll(@RequestParam(required = false) String orderCd) {
        try {
            List<OrderUpdateHistory> orderUpdateHistories = new ArrayList<>();

            if (orderCd == null) {
                orderUpdateHistoryRepository.findAll().forEach(orderUpdateHistories::add);
            } else {
                orderUpdateHistoryRepository.findByOrderCdContaining(orderCd).forEach(orderUpdateHistories::add);
            }

            if (orderUpdateHistories.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

            return new ResponseEntity<>(orderUpdateHistories, HttpStatus.OK);
        } catch (Exception e) {
            e.printStackTrace();
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/order_update_history/{id}")
    public ResponseEntity<OrderUpdateHistory> getById(@PathVariable("id") Integer id) {
        Optional<OrderUpdateHistory> data = orderUpdateHistoryRepository.findById(id);

        if (data.isPresent()) {
            return new ResponseEntity<>(data.get(), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @PostMapping("/order_update_history")
    public ResponseEntity<OrderUpdateHistory> create(@RequestBody OrderUpdateHistory orderUpdateHistory) {
        try {
            OrderUpdateHistory _orderUpdateHistory = orderUpdateHistoryRepository.save(new OrderUpdateHistory(
                    orderUpdateHistory.getOrderCd(),
                    orderUpdateHistory.getUpdateContent(),
                    orderUpdateHistory.getUpdateUserId(),
                    orderUpdateHistory.getUpdateDate(),
                    orderUpdateHistory.getVisibleFlg(),
                    orderUpdateHistory.getDelUserId(),
                    orderUpdateHistory.getDelDate(),
                    orderUpdateHistory.getDelFlg(),
                    orderUpdateHistory.getRevision()
            ));
            return new ResponseEntity<>(_orderUpdateHistory, HttpStatus.CREATED);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PutMapping("/order_update_history/{id}")
    public ResponseEntity<OrderUpdateHistory> update(@PathVariable("id") Integer id, @RequestBody OrderUpdateHistory orderUpdateHistory) {
        Optional<OrderUpdateHistory> data = orderUpdateHistoryRepository.findById(id);

        if (data.isPresent()) {
            OrderUpdateHistory _orderUpdateHistory = data.get();
            _orderUpdateHistory.setOrderCd(orderUpdateHistory.getOrderCd());
            _orderUpdateHistory.setUpdateContent(orderUpdateHistory.getUpdateContent());
            _orderUpdateHistory.setUpdateUserId(orderUpdateHistory.getUpdateUserId());
            _orderUpdateHistory.setUpdateDate(orderUpdateHistory.getUpdateDate());
            _orderUpdateHistory.setVisibleFlg(orderUpdateHistory.getVisibleFlg());
            _orderUpdateHistory.setDelUserId(orderUpdateHistory.getDelUserId());
            _orderUpdateHistory.setDelDate(orderUpdateHistory.getDelDate());
            _orderUpdateHistory.setDelFlg(orderUpdateHistory.getDelFlg());
            _orderUpdateHistory.setRevision(orderUpdateHistory.getRevision());
            return new ResponseEntity<>(orderUpdateHistoryRepository.save(_orderUpdateHistory), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/order_update_history/{id}")
    public ResponseEntity<HttpStatus> deleteById(@PathVariable("id") Integer id) {
        try {
            orderUpdateHistoryRepository.deleteById(id);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/order_update_history")
    public ResponseEntity<HttpStatus> deleteAll() {
        try {
            orderUpdateHistoryRepository.deleteAll();
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
