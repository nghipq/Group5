package com.minhtin.PhoneDB.controller;

import com.minhtin.PhoneDB.model.OtherMaster;
import com.minhtin.PhoneDB.repository.OtherMasterRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@CrossOrigin(origins = "http://localhost:8081")
@RestController
@RequestMapping("/api")
public class OtherMasterController {
    @Autowired
    OtherMasterRepository otherMasterRepository;

    @GetMapping("/other_master")
    public ResponseEntity<List<OtherMaster>> getAll(@RequestParam(required = false) String otherCd) {
        try {
            List<OtherMaster> otherMasters = new ArrayList<>();

            if (otherCd == null) {
                otherMasterRepository.findAll().forEach(otherMasters::add);
            } else {
                otherMasterRepository.findByOtherCdContaining(otherCd).forEach(otherMasters::add);
            }

            if (otherMasters.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

            return new ResponseEntity<>(otherMasters, HttpStatus.OK);
        } catch (Exception e) {
            e.printStackTrace();
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/other_master/{id}")
    public ResponseEntity<OtherMaster> getById(@PathVariable("id") Integer id) {
        Optional<OtherMaster> data = otherMasterRepository.findById(id);

        if (data.isPresent()) {
            return new ResponseEntity<>(data.get(), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @PostMapping("/other_master")
    public ResponseEntity<OtherMaster> create(@RequestBody OtherMaster otherMaster) {
        try {
            OtherMaster _otherMaster = otherMasterRepository.save(new OtherMaster(
                    otherMaster.getOtherCd(),
                    otherMaster.getOtherSubCd(),
                    otherMaster.getStringValue(),
                    otherMaster.getUpdateUserId(),
                    otherMaster.getUpdateDate(),
                    otherMaster.getVisibleFlg(),
                    otherMaster.getDelUserId(),
                    otherMaster.getDelDate(),
                    otherMaster.getDelFlg())
            );
            return new ResponseEntity<>(_otherMaster, HttpStatus.CREATED);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PutMapping("/other_master/{id}")
    public ResponseEntity<OtherMaster> update(@PathVariable("id") Integer id, @RequestBody OtherMaster otherMaster) {
        Optional<OtherMaster> data = otherMasterRepository.findById(id);

        if (data.isPresent()) {
            OtherMaster _otherMaster = data.get();
            _otherMaster.setOtherCd(otherMaster.getOtherCd());
            _otherMaster.setOtherSubCd(otherMaster.getOtherSubCd());
            _otherMaster.setStringValue(otherMaster.getStringValue());
            _otherMaster.setUpdateUserId(otherMaster.getUpdateUserId());
            _otherMaster.setUpdateDate(otherMaster.getUpdateDate());
            _otherMaster.setVisibleFlg(otherMaster.getVisibleFlg());
            _otherMaster.setDelUserId(otherMaster.getDelUserId());
            _otherMaster.setDelDate(otherMaster.getDelDate());
            _otherMaster.setDelFlg(otherMaster.getDelFlg());
            return new ResponseEntity<>(otherMasterRepository.save(_otherMaster), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/other_master/{id}")
    public ResponseEntity<HttpStatus> deleteById(@PathVariable("id") Integer id) {
        try {
            otherMasterRepository.deleteById(id);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/other_master")
    public ResponseEntity<HttpStatus> deleteAll() {
        try {
            otherMasterRepository.deleteAll();
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
