package com.minhtin.PhoneDB.controller;

import com.minhtin.PhoneDB.model.Product;
import com.minhtin.PhoneDB.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@CrossOrigin(origins = "http://localhost:8081")
@RestController
@RequestMapping("/api")
public class ProductController {
    @Autowired
    ProductRepository productRepository;

    @GetMapping("/product")
    public ResponseEntity<List<Product>> getAll(@RequestParam(required = false) String productCd) {
        try {
            List<Product> products = new ArrayList<>();

            if (productCd == null) {
                productRepository.findAll().forEach(products::add);
            } else {
                productRepository.findByProductCdContaining(productCd).forEach(products::add);
            }

            if (products.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

            return new ResponseEntity<>(products, HttpStatus.OK);
        } catch (Exception e) {
            e.printStackTrace();
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/product/{id}")
    public ResponseEntity<Product> getById(@PathVariable("id") Integer id) {
        Optional<Product> data = productRepository.findById(id);

        if (data.isPresent()) {
            return new ResponseEntity<>(data.get(), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @PostMapping("/product")
    public ResponseEntity<Product> create(@RequestBody Product product) {
        try {
            Product _product = productRepository.save(new Product(
                    product.getProductCd(),
                    product.getProductNm(),
                    product.getLinkedProductCd(),
                    product.getStoreCd(),
                    product.getStoreNm(),
                    product.getProductStatus(),
                    product.getDescription(),
                    product.getQuantity(),
                    product.getSale(),
                    product.getPrice(),
                    product.getDetailFile(),
                    product.getUpdateUserId(),
                    product.getUpdateDate(),
                    product.getVisibleFlg(),
                    product.getDelUserId(),
                    product.getDelDate(),
                    product.getDelFlg(),
                    product.getRevision()
            ));
            return new ResponseEntity<>(_product, HttpStatus.CREATED);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PutMapping("/product/{id}")
    public ResponseEntity<Product> update(@PathVariable("id") Integer id, @RequestBody Product product) {
        Optional<Product> data = productRepository.findById(id);

        if (data.isPresent()) {
            Product _product = data.get();
            _product.setProductCd(product.getProductCd());
            _product.setProductNm(product.getProductNm());
            _product.setLinkedProductCd(product.getLinkedProductCd());
            _product.setStoreCd(product.getStoreCd());
            _product.setStoreNm(product.getStoreNm());
            _product.setProductStatus(product.getProductStatus());
            _product.setDescription(product.getDescription());
            _product.setQuantity(product.getQuantity());
            _product.setSale(product.getSale());
            _product.setPrice(product.getPrice());
            _product.setDetailFile(product.getDetailFile());
            _product.setUpdateUserId(product.getUpdateUserId());
            _product.setUpdateDate(product.getUpdateDate());
            _product.setVisibleFlg(product.getVisibleFlg());
            _product.setDelUserId(product.getDelUserId());
            _product.setDelDate(product.getDelDate());
            _product.setDelFlg(product.getDelFlg());
            _product.setRevision(product.getRevision());
            return new ResponseEntity<>(productRepository.save(_product), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/product/{id}")
    public ResponseEntity<HttpStatus> deleteById(@PathVariable("id") Integer id) {
        try {
            productRepository.deleteById(id);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/product")
    public ResponseEntity<HttpStatus> deleteAll() {
        try {
            productRepository.deleteAll();
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
