package com.minhtin.PhoneDB.controller;

import com.minhtin.PhoneDB.model.ProductDetail;
import com.minhtin.PhoneDB.repository.ProductDetailRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@CrossOrigin(origins = "http://localhost:8081")
@RestController
@RequestMapping("/api")
public class ProductDetailController {
    @Autowired
    ProductDetailRepository productDetailRepository;

    @GetMapping("/product_detail")
    public ResponseEntity<List<ProductDetail>> getAll(@RequestParam(required = false) String productCd) {
        try {
            List<ProductDetail> productDetails = new ArrayList<>();

            if (productCd == null) {
                productDetailRepository.findAll().forEach(productDetails::add);
            } else {
                productDetailRepository.findByProductCdContaining(productCd).forEach(productDetails::add);
            }

            if (productDetails.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

            return new ResponseEntity<>(productDetails, HttpStatus.OK);
        } catch (Exception e) {
            e.printStackTrace();
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/product_detail/{id}")
    public ResponseEntity<ProductDetail> getById(@PathVariable("id") Integer id) {
        Optional<ProductDetail> data = productDetailRepository.findById(id);

        if (data.isPresent()) {
            return new ResponseEntity<>(data.get(), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @PostMapping("/product_detail")
    public ResponseEntity<ProductDetail> create(@RequestBody ProductDetail productDetail) {
        try {
            ProductDetail _product = productDetailRepository.save(new ProductDetail(
                    productDetail.getProductCd(),
                    productDetail.getmDetailCd(),
                    productDetail.getDetailType(),
                    productDetail.getDetailNm(),
                    productDetail.getDetailContent(),
                    productDetail.getDetailFile(),
                    productDetail.getUpdateUserId(),
                    productDetail.getUpdateDate(),
                    productDetail.getVisibleFlg(),
                    productDetail.getDelUserId(),
                    productDetail.getDelDate(),
                    productDetail.getDelFlg(),
                    productDetail.getRevision()
            ));
            return new ResponseEntity<>(_product, HttpStatus.CREATED);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PutMapping("/product_detail/{id}")
    public ResponseEntity<ProductDetail> update(@PathVariable("id") Integer id, @RequestBody ProductDetail productDetail) {
        Optional<ProductDetail> data = productDetailRepository.findById(id);

        if (data.isPresent()) {
            ProductDetail _productDetail = data.get();
            _productDetail.setProductCd(productDetail.getProductCd());
            _productDetail.setmDetailCd(productDetail.getmDetailCd());
            _productDetail.setDetailType(productDetail.getDetailType());
            _productDetail.setDetailNm(productDetail.getDetailNm());
            _productDetail.setDetailContent(productDetail.getDetailContent());
            _productDetail.setDetailFile(productDetail.getDetailFile());
            _productDetail.setUpdateUserId(productDetail.getUpdateUserId());
            _productDetail.setUpdateDate(productDetail.getUpdateDate());
            _productDetail.setVisibleFlg(productDetail.getVisibleFlg());
            _productDetail.setDelUserId(productDetail.getDelUserId());
            _productDetail.setDelDate(productDetail.getDelDate());
            _productDetail.setDelFlg(productDetail.getDelFlg());
            _productDetail.setRevision(productDetail.getRevision());
            return new ResponseEntity<>(productDetailRepository.save(_productDetail), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/product_detail/{id}")
    public ResponseEntity<HttpStatus> deleteById(@PathVariable("id") Integer id) {
        try {
            productDetailRepository.deleteById(id);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/product_detail")
    public ResponseEntity<HttpStatus> deleteAll() {
        try {
            productDetailRepository.deleteAll();
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
