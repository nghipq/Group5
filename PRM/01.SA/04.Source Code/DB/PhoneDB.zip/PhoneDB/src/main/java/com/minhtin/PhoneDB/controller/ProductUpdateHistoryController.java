package com.minhtin.PhoneDB.controller;

import com.minhtin.PhoneDB.model.ProductUpdateHistory;
import com.minhtin.PhoneDB.repository.ProductUpdateHistoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@CrossOrigin(origins = "http://localhost:8081")
@RestController
@RequestMapping("/api")
public class ProductUpdateHistoryController {
    @Autowired
    ProductUpdateHistoryRepository productUpdateHistoryRepository;

    @GetMapping("/product_update_history")
    public ResponseEntity<List<ProductUpdateHistory>> getAll(@RequestParam(required = false) String productCd) {
        try {
            List<ProductUpdateHistory> productUpdateHistories = new ArrayList<>();

            if (productCd == null) {
                productUpdateHistoryRepository.findAll().forEach(productUpdateHistories::add);
            } else {
                productUpdateHistoryRepository.findByProductCdContaining(productCd).forEach(productUpdateHistories::add);
            }

            if (productUpdateHistories.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

            return new ResponseEntity<>(productUpdateHistories, HttpStatus.OK);
        } catch (Exception e) {
            e.printStackTrace();
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/product_update_history/{id}")
    public ResponseEntity<ProductUpdateHistory> getById(@PathVariable("id") Integer id) {
        Optional<ProductUpdateHistory> data = productUpdateHistoryRepository.findById(id);

        if (data.isPresent()) {
            return new ResponseEntity<>(data.get(), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @PostMapping("/product_update_history")
    public ResponseEntity<ProductUpdateHistory> create(@RequestBody ProductUpdateHistory productUpdateHistory) {
        try {
            ProductUpdateHistory _product = productUpdateHistoryRepository.save(new ProductUpdateHistory(
                    productUpdateHistory.getProductCd(),
                    productUpdateHistory.getUpdateContent(),
                    productUpdateHistory.getUpdateUserId(),
                    productUpdateHistory.getUpdateDate(),
                    productUpdateHistory.getVisibleFlg(),
                    productUpdateHistory.getDelUserId(),
                    productUpdateHistory.getDelDate(),
                    productUpdateHistory.getDelFlg(),
                    productUpdateHistory.getRevision()
            ));
            return new ResponseEntity<>(_product, HttpStatus.CREATED);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PutMapping("/product_update_history/{id}")
    public ResponseEntity<ProductUpdateHistory> update(@PathVariable("id") Integer id, @RequestBody ProductUpdateHistory productUpdateHistory) {
        Optional<ProductUpdateHistory> data = productUpdateHistoryRepository.findById(id);

        if (data.isPresent()) {
            ProductUpdateHistory _productUpdateHistory = data.get();
            _productUpdateHistory.setProductCd(productUpdateHistory.getProductCd());
            _productUpdateHistory.setUpdateContent(productUpdateHistory.getUpdateContent());
            _productUpdateHistory.setUpdateUserId(productUpdateHistory.getUpdateUserId());
            _productUpdateHistory.setUpdateDate(productUpdateHistory.getUpdateDate());
            _productUpdateHistory.setVisibleFlg(productUpdateHistory.getVisibleFlg());
            _productUpdateHistory.setDelUserId(productUpdateHistory.getDelUserId());
            _productUpdateHistory.setDelDate(productUpdateHistory.getDelDate());
            _productUpdateHistory.setDelFlg(productUpdateHistory.getDelFlg());
            _productUpdateHistory.setRevision(productUpdateHistory.getRevision());
            return new ResponseEntity<>(productUpdateHistoryRepository.save(_productUpdateHistory), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/product_update_history/{id}")
    public ResponseEntity<HttpStatus> deleteById(@PathVariable("id") Integer id) {
        try {
            productUpdateHistoryRepository.deleteById(id);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/product_update_history")
    public ResponseEntity<HttpStatus> deleteAll() {
        try {
            productUpdateHistoryRepository.deleteAll();
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
