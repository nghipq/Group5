package com.minhtin.PhoneDB.controller;

import com.minhtin.PhoneDB.model.ServiceMaster;
import com.minhtin.PhoneDB.repository.ServiceMasterRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@CrossOrigin(origins = "http://localhost:8081")
@RestController
@RequestMapping("/api")
public class ServiceMasterController {
    @Autowired
    ServiceMasterRepository serviceMasterRepository;

    @GetMapping("/service_mater")
    public ResponseEntity<List<ServiceMaster>> getAll(@RequestParam(required = false) String serviceCd) {
        try {
            List<ServiceMaster> serviceMasters = new ArrayList<>();

            if (serviceCd == null) {
                serviceMasterRepository.findAll().forEach(serviceMasters::add);
            } else {
                serviceMasterRepository.findByServiceCdContaining(serviceCd).forEach(serviceMasters::add);
            }

            if (serviceMasters.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

            return new ResponseEntity<>(serviceMasters, HttpStatus.OK);
        } catch (Exception e) {
            e.printStackTrace();
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/service_mater/{id}")
    public ResponseEntity<ServiceMaster> getById(@PathVariable("id") Integer id) {
        Optional<ServiceMaster> data = serviceMasterRepository.findById(id);

        if (data.isPresent()) {
            return new ResponseEntity<>(data.get(), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @PostMapping("/service_mater")
    public ResponseEntity<ServiceMaster> create(@RequestBody ServiceMaster serviceMaster) {
        try {
            ServiceMaster _product = serviceMasterRepository.save(new ServiceMaster(
                    serviceMaster.getServiceCd(),
                    serviceMaster.getServiceNm(),
                    serviceMaster.getServiceContent(),
                    serviceMaster.getServiceRate(),
                    serviceMaster.getUpdateUserId(),
                    serviceMaster.getUpdateDate(),
                    serviceMaster.getVisibleFlg(),
                    serviceMaster.getDelUserId(),
                    serviceMaster.getDelDate(),
                    serviceMaster.getDelFlg(),
                    serviceMaster.getRevision()
            ));
            return new ResponseEntity<>(_product, HttpStatus.CREATED);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PutMapping("/service_mater/{id}")
    public ResponseEntity<ServiceMaster> update(@PathVariable("id") Integer id, @RequestBody ServiceMaster serviceMaster) {
        Optional<ServiceMaster> data = serviceMasterRepository.findById(id);

        if (data.isPresent()) {
            ServiceMaster _serviceMaster = data.get();
            _serviceMaster.setServiceCd(serviceMaster.getServiceCd());
            _serviceMaster.setServiceNm(serviceMaster.getServiceNm());
            _serviceMaster.setServiceContent(serviceMaster.getServiceContent());
            _serviceMaster.setServiceRate(serviceMaster.getServiceRate());
            _serviceMaster.setUpdateUserId(serviceMaster.getUpdateUserId());
            _serviceMaster.setUpdateDate(serviceMaster.getUpdateDate());
            _serviceMaster.setVisibleFlg(serviceMaster.getVisibleFlg());
            _serviceMaster.setDelUserId(serviceMaster.getDelUserId());
            _serviceMaster.setDelDate(serviceMaster.getDelDate());
            _serviceMaster.setDelFlg(serviceMaster.getDelFlg());
            _serviceMaster.setRevision(serviceMaster.getRevision());
            return new ResponseEntity<>(serviceMasterRepository.save(_serviceMaster), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/service_mater/{id}")
    public ResponseEntity<HttpStatus> deleteById(@PathVariable("id") Integer id) {
        try {
            serviceMasterRepository.deleteById(id);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/service_mater")
    public ResponseEntity<HttpStatus> deleteAll() {
        try {
            serviceMasterRepository.deleteAll();
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
