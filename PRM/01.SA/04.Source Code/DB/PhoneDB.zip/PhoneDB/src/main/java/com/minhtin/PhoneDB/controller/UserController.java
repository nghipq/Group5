package com.minhtin.PhoneDB.controller;

import com.minhtin.PhoneDB.model.User;
import com.minhtin.PhoneDB.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@CrossOrigin(origins = "http://localhost:8081")
@RestController
@RequestMapping("/api")
public class UserController {
    @Autowired
    UserRepository userRepository;

    @GetMapping("/user")
    public ResponseEntity<List<User>> getAll(@RequestParam(required = false) String userCd) {
        try {
            List<User> users = new ArrayList<>();

            if (userCd == null) {
                userRepository.findAll().forEach(users::add);
            } else {
                userRepository.findByUserCdContaining(userCd).forEach(users::add);
            }

            if (users.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

            return new ResponseEntity<>(users, HttpStatus.OK);
        } catch (Exception e) {
            e.printStackTrace();
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/user/{id}")
    public ResponseEntity<User> getById(@PathVariable("id") Integer id) {
        Optional<User> data = userRepository.findById(id);

        if (data.isPresent()) {
            return new ResponseEntity<>(data.get(), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @PostMapping("/user")
    public ResponseEntity<User> create(@RequestBody User user) {
        try {
            User _user = userRepository.save(new User(
                    user.getUserCd(),
                    user.getUserNm(),
                    user.getUserType(),
                    user.getPhone(),
                    user.getSubPhone(),
                    user.getEmail(),
                    user.getPassword(),
                    user.getAddress1(),
                    user.getAddress2(),
                    user.getAddress3(),
                    user.getAddress4(),
                    user.getAge(),
                    user.getBirthday(),
                    user.getPostNo(),
                    user.getUpdateUserId(),
                    user.getUpdateDate(),
                    user.getVisibleFlg(),
                    user.getDelUserId(),
                    user.getDelDate(),
                    user.getDelFlg(),
                    user.getRevision()
            ));
            return new ResponseEntity<>(_user, HttpStatus.CREATED);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PutMapping("/user/{id}")
    public ResponseEntity<User> update(@PathVariable("id") Integer id, @RequestBody User user) {
        Optional<User> data = userRepository.findById(id);

        if (data.isPresent()) {
            User _user = data.get();
            _user.setUserCd(user.getUserCd());
            _user.setUserNm(user.getUserNm());
            _user.setUserType(user.getUserType());
            _user.setPhone(user.getPhone());
            _user.setSubPhone(user.getSubPhone());
            _user.setEmail(user.getEmail());
            _user.setPassword(user.getPassword());
            _user.setAddress1(user.getAddress1());
            _user.setAddress2(user.getAddress2());
            _user.setAddress3(user.getAddress3());
            _user.setAddress4(user.getAddress4());
            _user.setAge(user.getAge());
            _user.setBirthday(user.getBirthday());
            _user.setPostNo(user.getPostNo());
            _user.setUpdateUserId(user.getUpdateUserId());
            _user.setUpdateDate(user.getUpdateDate());
            _user.setVisibleFlg(user.getVisibleFlg());
            _user.setDelUserId(user.getDelUserId());
            _user.setDelDate(user.getDelDate());
            _user.setDelFlg(user.getDelFlg());
            _user.setRevision(user.getRevision());
            return new ResponseEntity<>(userRepository.save(_user), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/user/{id}")
    public ResponseEntity<HttpStatus> deleteById(@PathVariable("id") Integer id) {
        try {
            userRepository.deleteById(id);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/user")
    public ResponseEntity<HttpStatus> deleteAll() {
        try {
            userRepository.deleteAll();
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
