package com.minhtin.PhoneDB.controller;

import com.minhtin.PhoneDB.model.UserDetail;
import com.minhtin.PhoneDB.repository.UserDetailRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@CrossOrigin(origins = "http://localhost:8081")
@RestController
@RequestMapping("/api")
public class UserDetailController {
    @Autowired
    UserDetailRepository userDetailRepository;

    @GetMapping("/user_detail")
    public ResponseEntity<List<UserDetail>> getAll(@RequestParam(required = false) String userCd) {
        try {
            List<UserDetail> userDetails = new ArrayList<>();

            if (userCd == null) {
                userDetailRepository.findAll().forEach(userDetails::add);
            } else {
                userDetailRepository.findByUserCdContaining(userCd).forEach(userDetails::add);
            }

            if (userDetails.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

            return new ResponseEntity<>(userDetails, HttpStatus.OK);
        } catch (Exception e) {
            e.printStackTrace();
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/user_detail/{id}")
    public ResponseEntity<UserDetail> getById(@PathVariable("id") Integer id) {
        Optional<UserDetail> data = userDetailRepository.findById(id);

        if (data.isPresent()) {
            return new ResponseEntity<>(data.get(), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @PostMapping("/user_detail")
    public ResponseEntity<UserDetail> create(@RequestBody UserDetail userDetail) {
        try {
            UserDetail _userDetail = userDetailRepository.save(new UserDetail(
                    userDetail.getUserCd(),
                    userDetail.getUserNm(),
                    userDetail.getUserType(),
                    userDetail.getPhone(),
                    userDetail.getSubPhone(),
                    userDetail.getEmail(),
                    userDetail.getPassword(),
                    userDetail.getAddress1(),
                    userDetail.getAddress2(),
                    userDetail.getAddress3(),
                    userDetail.getAddress4(),
                    userDetail.getAge(),
                    userDetail.getBirthday(),
                    userDetail.getPostNo(),
                    userDetail.getUpdateUserId(),
                    userDetail.getUpdateDate(),
                    userDetail.getVisibleFlg(),
                    userDetail.getDelUserId(),
                    userDetail.getDelDate(),
                    userDetail.getDelFlg(),
                    userDetail.getRevision()
            ));
            return new ResponseEntity<>(_userDetail, HttpStatus.CREATED);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PutMapping("/user_detail/{id}")
    public ResponseEntity<UserDetail> update(@PathVariable("id") Integer id, @RequestBody UserDetail userDetail) {
        Optional<UserDetail> data = userDetailRepository.findById(id);

        if (data.isPresent()) {
            UserDetail _user = data.get();
            _user.setUserCd(userDetail.getUserCd());
            _user.setUserNm(userDetail.getUserNm());
            _user.setUserType(userDetail.getUserType());
            _user.setPhone(userDetail.getPhone());
            _user.setSubPhone(userDetail.getSubPhone());
            _user.setEmail(userDetail.getEmail());
            _user.setPassword(userDetail.getPassword());
            _user.setAddress1(userDetail.getAddress1());
            _user.setAddress2(userDetail.getAddress2());
            _user.setAddress3(userDetail.getAddress3());
            _user.setAddress4(userDetail.getAddress4());
            _user.setAge(userDetail.getAge());
            _user.setBirthday(userDetail.getBirthday());
            _user.setPostNo(userDetail.getPostNo());
            _user.setUpdateUserId(userDetail.getUpdateUserId());
            _user.setUpdateDate(userDetail.getUpdateDate());
            _user.setVisibleFlg(userDetail.getVisibleFlg());
            _user.setDelUserId(userDetail.getDelUserId());
            _user.setDelDate(userDetail.getDelDate());
            _user.setDelFlg(userDetail.getDelFlg());
            _user.setRevision(userDetail.getRevision());
            return new ResponseEntity<>(userDetailRepository.save(_user), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/user_detail/{id}")
    public ResponseEntity<HttpStatus> deleteById(@PathVariable("id") Integer id) {
        try {
            userDetailRepository.deleteById(id);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/user_detail")
    public ResponseEntity<HttpStatus> deleteAll() {
        try {
            userDetailRepository.deleteAll();
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
