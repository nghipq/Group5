package com.minhtin.PhoneDB.model;

import javax.persistence.*;
import java.sql.Date;

@Entity
@Table(name = "CategoryMaster")
public class CategoryMaster {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "seq")
    private Integer seq;

    @Column(name = "category_cd")
    private String categoryCd;

    @Column(name = "category_nm")
    private String categoryNm;

    @Column(name = "category_content")
    private String categoryContent;

    @Column(name = "link_category_cd")
    private String linkCategoryCd;

    @Column(name = "update_user_id")
    private String updateUserId;

    @Column(name = "update_date")
    private Date updateDate;

    @Column(name = "visible_flg")
    private String visibleFlg;

    @Column(name = "del_user_id")
    private String delUserId;

    @Column(name = "del_date")
    private Date delDate;

    @Column(name = "del_flg")
    private String delFlg;

    @Column(name = "revision")
    private Integer revision;

    public CategoryMaster() {
    }

    public CategoryMaster(String categoryCd, String categoryNm, String categoryContent, String linkCategoryCd, String updateUserId, Date updateDate, String visibleFlg, String delUserId, Date delDate, String delFlg, Integer revision) {
        this.categoryCd = categoryCd;
        this.categoryNm = categoryNm;
        this.categoryContent = categoryContent;
        this.linkCategoryCd = linkCategoryCd;
        this.updateUserId = updateUserId;
        this.updateDate = updateDate;
        this.visibleFlg = visibleFlg;
        this.delUserId = delUserId;
        this.delDate = delDate;
        this.delFlg = delFlg;
        this.revision = revision;
    }

    public Integer getSeq() {
        return seq;
    }

    public void setSeq(Integer seq) {
        this.seq = seq;
    }

    public String getCategoryCd() {
        return categoryCd;
    }

    public void setCategoryCd(String categoryCd) {
        this.categoryCd = categoryCd;
    }

    public String getCategoryNm() {
        return categoryNm;
    }

    public void setCategoryNm(String categoryNm) {
        this.categoryNm = categoryNm;
    }

    public String getCategoryContent() {
        return categoryContent;
    }

    public void setCategoryContent(String categoryContent) {
        this.categoryContent = categoryContent;
    }

    public String getLinkCategoryCd() {
        return linkCategoryCd;
    }

    public void setLinkCategoryCd(String linkCategoryCd) {
        this.linkCategoryCd = linkCategoryCd;
    }

    public String getUpdateUserId() {
        return updateUserId;
    }

    public void setUpdateUserId(String updateUserId) {
        this.updateUserId = updateUserId;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

    public String getVisibleFlg() {
        return visibleFlg;
    }

    public void setVisibleFlg(String visibleFlg) {
        this.visibleFlg = visibleFlg;
    }

    public String getDelUserId() {
        return delUserId;
    }

    public void setDelUserId(String delUserId) {
        this.delUserId = delUserId;
    }

    public Date getDelDate() {
        return delDate;
    }

    public void setDelDate(Date delDate) {
        this.delDate = delDate;
    }

    public String getDelFlg() {
        return delFlg;
    }

    public void setDelFlg(String delFlg) {
        this.delFlg = delFlg;
    }

    public Integer getRevision() {
        return revision;
    }

    public void setRevision(Integer revision) {
        this.revision = revision;
    }
}
