package com.minhtin.PhoneDB.model;

import javax.persistence.*;
import java.sql.Date;

@Entity
@Table(name = "OrderDetail")
public class OrderDetail {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "seq")
    private Integer seq;

    @Column(name = "order_cd")
    private String orderCd;

    @Column(name = "product_cd")
    private String productCd;

    @Column(name = "product_nm")
    private String productNm;

    @Column(name = "shipper_cd")
    private String shipperCd;

    @Column(name = "shipper_nm")
    private String shipperNm;

    @Column(name = "store_cd")
    private String storeCd;

    @Column(name = "store_nm")
    private String storeNm;

    @Column(name = "date_from")
    private Date dateFrom;

    @Column(name = "date_to")
    private Date dateTo;

    @Column(name = "price")
    private String price;

    @Column(name = "quantity")
    private Integer quantity;

    @Column(name = "service_cd")
    private String serviceCd;

    @Column(name = "service_nm")
    private String serviceNm;

    @Column(name = "update_user_id")
    private String updateUserId;

    @Column(name = "update_date")
    private Date updateDate;

    @Column(name = "visible_flg")
    private String visibleFlg;

    @Column(name = "del_user_id")
    private String delUserId;

    @Column(name = "del_date")
    private Date delDate;

    @Column(name = "del_flg")
    private String delFlg;

    @Column(name = "revision")
    private Integer revision;

    public OrderDetail() {
    }

    public OrderDetail(String orderCd, String productCd, String productNm, String shipperCd, String shipperNm, String storeCd, String storeNm, Date dateFrom, Date dateTo, String price, Integer quantity, String serviceCd, String serviceNm, String updateUserId, Date updateDate, String visibleFlg, String delUserId, Date delDate, String delFlg, Integer revision) {
        this.orderCd = orderCd;
        this.productCd = productCd;
        this.productNm = productNm;
        this.shipperCd = shipperCd;
        this.shipperNm = shipperNm;
        this.storeCd = storeCd;
        this.storeNm = storeNm;
        this.dateFrom = dateFrom;
        this.dateTo = dateTo;
        this.price = price;
        this.quantity = quantity;
        this.serviceCd = serviceCd;
        this.serviceNm = serviceNm;
        this.updateUserId = updateUserId;
        this.updateDate = updateDate;
        this.visibleFlg = visibleFlg;
        this.delUserId = delUserId;
        this.delDate = delDate;
        this.delFlg = delFlg;
        this.revision = revision;
    }

    public Integer getSeq() {
        return seq;
    }

    public void setSeq(Integer seq) {
        this.seq = seq;
    }

    public String getOrderCd() {
        return orderCd;
    }

    public void setOrderCd(String orderCd) {
        this.orderCd = orderCd;
    }

    public String getProductCd() {
        return productCd;
    }

    public void setProductCd(String productCd) {
        this.productCd = productCd;
    }

    public String getProductNm() {
        return productNm;
    }

    public void setProductNm(String productNm) {
        this.productNm = productNm;
    }

    public String getShipperCd() {
        return shipperCd;
    }

    public void setShipperCd(String shipperCd) {
        this.shipperCd = shipperCd;
    }

    public String getShipperNm() {
        return shipperNm;
    }

    public void setShipperNm(String shipperNm) {
        this.shipperNm = shipperNm;
    }

    public String getStoreCd() {
        return storeCd;
    }

    public void setStoreCd(String storeCd) {
        this.storeCd = storeCd;
    }

    public String getStoreNm() {
        return storeNm;
    }

    public void setStoreNm(String storeNm) {
        this.storeNm = storeNm;
    }

    public Date getDateFrom() {
        return dateFrom;
    }

    public void setDateFrom(Date dateFrom) {
        this.dateFrom = dateFrom;
    }

    public Date getDateTo() {
        return dateTo;
    }

    public void setDateTo(Date dateTo) {
        this.dateTo = dateTo;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    public String getServiceCd() {
        return serviceCd;
    }

    public void setServiceCd(String serviceCd) {
        this.serviceCd = serviceCd;
    }

    public String getServiceNm() {
        return serviceNm;
    }

    public void setServiceNm(String serviceNm) {
        this.serviceNm = serviceNm;
    }

    public String getUpdateUserId() {
        return updateUserId;
    }

    public void setUpdateUserId(String updateUserId) {
        this.updateUserId = updateUserId;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

    public String getVisibleFlg() {
        return visibleFlg;
    }

    public void setVisibleFlg(String visibleFlg) {
        this.visibleFlg = visibleFlg;
    }

    public String getDelUserId() {
        return delUserId;
    }

    public void setDelUserId(String delUserId) {
        this.delUserId = delUserId;
    }

    public Date getDelDate() {
        return delDate;
    }

    public void setDelDate(Date delDate) {
        this.delDate = delDate;
    }

    public String getDelFlg() {
        return delFlg;
    }

    public void setDelFlg(String delFlg) {
        this.delFlg = delFlg;
    }

    public Integer getRevision() {
        return revision;
    }

    public void setRevision(Integer revision) {
        this.revision = revision;
    }
}
