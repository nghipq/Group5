package com.minhtin.PhoneDB.model;

import javax.persistence.*;
import java.sql.Date;

@Entity
@Table(name = "OtherMaster")
public class OtherMaster {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "seq")
    private Integer seq;

    @Column(name = "other_cd")
    private String otherCd;

    @Column(name = "other_sub_cd")
    private String otherSubCd;

    @Column(name = "string_value")
    private String stringValue;

    @Column(name = "update_user_id")
    private String updateUserId;

    @Column(name = "update_date")
    private Date updateDate;

    @Column(name = "visible_flg")
    private String visibleFlg;

    @Column(name = "del_user_id")
    private String delUserId;

    @Column(name = "del_date")
    private Date delDate;

    @Column(name = "del_flg")
    private String delFlg;

    public OtherMaster() {
    }

    public OtherMaster(String otherCd, String otherSubCd, String stringValue, String updateUserId, Date updateDate, String visibleFlg, String delUserId, Date delDate, String delFlg) {
        this.otherCd = otherCd;
        this.otherSubCd = otherSubCd;
        this.stringValue = stringValue;
        this.updateUserId = updateUserId;
        this.updateDate = updateDate;
        this.visibleFlg = visibleFlg;
        this.delUserId = delUserId;
        this.delDate = delDate;
        this.delFlg = delFlg;
    }

    public Integer getSeq() {
        return seq;
    }

    public void setSeq(Integer seq) {
        this.seq = seq;
    }

    public String getOtherCd() {
        return otherCd;
    }

    public void setOtherCd(String otherCd) {
        this.otherCd = otherCd;
    }

    public String getOtherSubCd() {
        return otherSubCd;
    }

    public void setOtherSubCd(String otherSubCd) {
        this.otherSubCd = otherSubCd;
    }

    public String getStringValue() {
        return stringValue;
    }

    public void setStringValue(String stringValue) {
        this.stringValue = stringValue;
    }

    public String getUpdateUserId() {
        return updateUserId;
    }

    public void setUpdateUserId(String updateUserId) {
        this.updateUserId = updateUserId;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

    public String getVisibleFlg() {
        return visibleFlg;
    }

    public void setVisibleFlg(String visibleFlg) {
        this.visibleFlg = visibleFlg;
    }

    public String getDelUserId() {
        return delUserId;
    }

    public void setDelUserId(String delUserId) {
        this.delUserId = delUserId;
    }

    public Date getDelDate() {
        return delDate;
    }

    public void setDelDate(Date delDate) {
        this.delDate = delDate;
    }

    public String getDelFlg() {
        return delFlg;
    }

    public void setDelFlg(String delFlg) {
        this.delFlg = delFlg;
    }
}
