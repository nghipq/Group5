package com.minhtin.PhoneDB.model;

import javax.persistence.*;
import java.sql.Date;

@Entity
@Table(name = "Product")
public class Product {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "seq")
    private Integer seq;

    @Column(name = "product_cd")
    private String productCd;

    @Column(name = "product_nm")
    private String productNm;

    @Column(name = "linked_product_cd")
    private String linkedProductCd;

    @Column(name = "store_cd")
    private String storeCd;

    @Column(name = "store_nm")
    private String storeNm;

    @Column(name = "product_status")
    private String productStatus;

    @Column(name = "description")
    private String description;

    @Column(name = "quantity")
    private Integer quantity;

    @Column(name = "sale")
    private Double sale;

    @Column(name = "price")
    private String price;

    @Column(name = "detail_file")
    private String detailFile;

    @Column(name = "update_user_id")
    private String updateUserId;

    @Column(name = "update_date")
    private Date updateDate;

    @Column(name = "visible_flg")
    private String visibleFlg;

    @Column(name = "del_user_id")
    private String delUserId;

    @Column(name = "del_date")
    private Date delDate;

    @Column(name = "del_flg")
    private String delFlg;

    @Column(name = "revision")
    private Integer revision;

    public Product() {
    }

    public Product(String productCd, String productNm, String linkedProductCd, String storeCd, String storeNm, String productStatus, String description, Integer quantity, Double sale, String price, String detailFile, String updateUserId, Date updateDate, String visibleFlg, String delUserId, Date delDate, String delFlg, Integer revision) {
        this.productCd = productCd;
        this.productNm = productNm;
        this.linkedProductCd = linkedProductCd;
        this.storeCd = storeCd;
        this.storeNm = storeNm;
        this.productStatus = productStatus;
        this.description = description;
        this.quantity = quantity;
        this.sale = sale;
        this.price = price;
        this.detailFile = detailFile;
        this.updateUserId = updateUserId;
        this.updateDate = updateDate;
        this.visibleFlg = visibleFlg;
        this.delUserId = delUserId;
        this.delDate = delDate;
        this.delFlg = delFlg;
        this.revision = revision;
    }

    public Integer getSeq() {
        return seq;
    }

    public void setSeq(Integer seq) {
        this.seq = seq;
    }

    public String getProductCd() {
        return productCd;
    }

    public void setProductCd(String productCd) {
        this.productCd = productCd;
    }

    public String getProductNm() {
        return productNm;
    }

    public void setProductNm(String productNm) {
        this.productNm = productNm;
    }

    public String getLinkedProductCd() {
        return linkedProductCd;
    }

    public void setLinkedProductCd(String linkedProductCd) {
        this.linkedProductCd = linkedProductCd;
    }

    public String getStoreCd() {
        return storeCd;
    }

    public void setStoreCd(String storeCd) {
        this.storeCd = storeCd;
    }

    public String getStoreNm() {
        return storeNm;
    }

    public void setStoreNm(String storeNm) {
        this.storeNm = storeNm;
    }

    public String getProductStatus() {
        return productStatus;
    }

    public void setProductStatus(String productStatus) {
        this.productStatus = productStatus;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    public Double getSale() {
        return sale;
    }

    public void setSale(Double sale) {
        this.sale = sale;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getDetailFile() {
        return detailFile;
    }

    public void setDetailFile(String detailFile) {
        this.detailFile = detailFile;
    }

    public String getUpdateUserId() {
        return updateUserId;
    }

    public void setUpdateUserId(String updateUserId) {
        this.updateUserId = updateUserId;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

    public String getVisibleFlg() {
        return visibleFlg;
    }

    public void setVisibleFlg(String visibleFlg) {
        this.visibleFlg = visibleFlg;
    }

    public String getDelUserId() {
        return delUserId;
    }

    public void setDelUserId(String delUserId) {
        this.delUserId = delUserId;
    }

    public Date getDelDate() {
        return delDate;
    }

    public void setDelDate(Date delDate) {
        this.delDate = delDate;
    }

    public String getDelFlg() {
        return delFlg;
    }

    public void setDelFlg(String delFlg) {
        this.delFlg = delFlg;
    }

    public Integer getRevision() {
        return revision;
    }

    public void setRevision(Integer revision) {
        this.revision = revision;
    }
}
