package com.minhtin.PhoneDB.model;

import javax.persistence.*;
import java.sql.Date;

@Entity
@Table(name = "ProductUpdateHistory")
public class ProductUpdateHistory {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "seq")
    private Integer seq;

    @Column(name = "product_cd")
    private String productCd;

    @Column(name = "update_content")
    private String updateContent;

    @Column(name = "update_user_id")
    private String updateUserId;

    @Column(name = "update_date")
    private Date updateDate;

    @Column(name = "visible_flg")
    private String visibleFlg;

    @Column(name = "del_user_id")
    private String delUserId;

    @Column(name = "del_date")
    private Date delDate;

    @Column(name = "del_flg")
    private String delFlg;

    @Column(name = "revision")
    private Integer revision;

    public ProductUpdateHistory() {
    }

    public ProductUpdateHistory(String productCd, String updateContent, String updateUserId, Date updateDate, String visibleFlg, String delUserId, Date delDate, String delFlg, Integer revision) {
        this.productCd = productCd;
        this.updateContent = updateContent;
        this.updateUserId = updateUserId;
        this.updateDate = updateDate;
        this.visibleFlg = visibleFlg;
        this.delUserId = delUserId;
        this.delDate = delDate;
        this.delFlg = delFlg;
        this.revision = revision;
    }

    public Integer getSeq() {
        return seq;
    }

    public void setSeq(Integer seq) {
        this.seq = seq;
    }

    public String getProductCd() {
        return productCd;
    }

    public void setProductCd(String productCd) {
        this.productCd = productCd;
    }

    public String getUpdateContent() {
        return updateContent;
    }

    public void setUpdateContent(String updateContent) {
        this.updateContent = updateContent;
    }

    public String getUpdateUserId() {
        return updateUserId;
    }

    public void setUpdateUserId(String updateUserId) {
        this.updateUserId = updateUserId;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

    public String getVisibleFlg() {
        return visibleFlg;
    }

    public void setVisibleFlg(String visibleFlg) {
        this.visibleFlg = visibleFlg;
    }

    public String getDelUserId() {
        return delUserId;
    }

    public void setDelUserId(String delUserId) {
        this.delUserId = delUserId;
    }

    public Date getDelDate() {
        return delDate;
    }

    public void setDelDate(Date delDate) {
        this.delDate = delDate;
    }

    public String getDelFlg() {
        return delFlg;
    }

    public void setDelFlg(String delFlg) {
        this.delFlg = delFlg;
    }

    public Integer getRevision() {
        return revision;
    }

    public void setRevision(Integer revision) {
        this.revision = revision;
    }
}
