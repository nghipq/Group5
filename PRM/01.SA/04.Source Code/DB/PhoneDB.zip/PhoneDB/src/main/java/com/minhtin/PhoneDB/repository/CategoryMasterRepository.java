package com.minhtin.PhoneDB.repository;

import com.minhtin.PhoneDB.model.CategoryMaster;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface CategoryMasterRepository extends JpaRepository<CategoryMaster, Integer> {
    List<CategoryMaster> findByCategoryCdContaining(String categoryCd);
}
