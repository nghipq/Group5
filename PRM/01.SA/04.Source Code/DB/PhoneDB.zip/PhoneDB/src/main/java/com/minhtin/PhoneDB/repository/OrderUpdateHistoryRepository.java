package com.minhtin.PhoneDB.repository;

import com.minhtin.PhoneDB.model.OrderUpdateHistory;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface OrderUpdateHistoryRepository extends JpaRepository<OrderUpdateHistory, Integer> {
    List<OrderUpdateHistory> findByOrderCdContaining(String orderCd);
}
