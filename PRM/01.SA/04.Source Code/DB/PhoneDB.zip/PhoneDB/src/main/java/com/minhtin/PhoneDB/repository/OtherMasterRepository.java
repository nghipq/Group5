package com.minhtin.PhoneDB.repository;

import com.minhtin.PhoneDB.model.OtherMaster;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface OtherMasterRepository extends JpaRepository<OtherMaster, Integer> {
    List<OtherMaster> findByOtherCdContaining(String otherCd);
}
