package com.minhtin.PhoneDB.repository;

import com.minhtin.PhoneDB.model.ProductDetail;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ProductDetailRepository extends JpaRepository<ProductDetail, Integer> {
    List<ProductDetail> findByProductCdContaining(String productCd);
}
