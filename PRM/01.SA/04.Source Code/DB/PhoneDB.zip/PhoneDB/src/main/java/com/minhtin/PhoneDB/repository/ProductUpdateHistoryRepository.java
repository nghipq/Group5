package com.minhtin.PhoneDB.repository;

import com.minhtin.PhoneDB.model.ProductUpdateHistory;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ProductUpdateHistoryRepository extends JpaRepository<ProductUpdateHistory, Integer> {
    List<ProductUpdateHistory> findByProductCdContaining(String productCd);
}
