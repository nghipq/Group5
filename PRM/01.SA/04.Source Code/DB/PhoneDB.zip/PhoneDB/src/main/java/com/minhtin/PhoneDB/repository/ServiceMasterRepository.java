package com.minhtin.PhoneDB.repository;

import com.minhtin.PhoneDB.model.ServiceMaster;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ServiceMasterRepository extends JpaRepository<ServiceMaster, Integer> {
    List<ServiceMaster> findByServiceCdContaining(String serviceCd);
}
