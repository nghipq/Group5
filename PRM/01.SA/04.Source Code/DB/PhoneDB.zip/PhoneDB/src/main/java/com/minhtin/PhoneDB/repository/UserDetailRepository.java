package com.minhtin.PhoneDB.repository;

import com.minhtin.PhoneDB.model.UserDetail;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface UserDetailRepository extends JpaRepository<UserDetail, Integer> {
    List<UserDetail> findByUserCdContaining(String userCd);
}
